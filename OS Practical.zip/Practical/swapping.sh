#!/bin/bash
echo "enter the first number"
read first
echo "enter the second number"
read second
temp=$first
first=$second
second=$temp
echo "After swapping, numbers are:"
echo "first = $first, second = $second"
